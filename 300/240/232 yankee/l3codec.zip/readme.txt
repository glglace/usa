Installing the MPEG Layer-3 codec is very simple.  

First, unzip this archive to a work directory - for instance, C:\TEMP.  Do not just open the file with WinZip.  You MUST EXTRACT all of the files to a work directory.

Next, open Windows Explorer and go to the work directory.  Right-click on the INSTALL.INF file, and choose the INSTALL menu command.

The codec should work right away - if not, try rebooting your system,